package model;

import persistencia.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import persistencia.Inventariable;

public class RegistroHawkins<T extends CSVSerializable> implements Inventariable<T>{
    
    private List<T> elementos = new ArrayList<>();
    
    @Override
    public void agregar(T elemento){
        Objects.requireNonNull(elemento, "Elemento nulo");
        elementos.add(elemento);
    }
    
    private void validarIndice(int index){
        if(index < 0 || index >= elementos.size()){
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }
    
    @Override
    public T obtener(int indice){
        validarIndice(indice);
        return elementos.get(indice);
    }
    
    @Override
    public void eliminar(int index){
        validarIndice(index);
        elementos.remove(index);
    }

    @Override
    public void paraCadaElemento(Consumer<T> accion) {
        for (T elem : elementos) {
            accion.accept(elem);
        }
    }
    
    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrada = new ArrayList<>();
        for (T elem : elementos) {
            if (criterio.test(elem)) {
                filtrada.add(elem);
            }
        }
        return filtrada;
    }
    
    public void ordenar(Comparator<? super T> comp){
        elementos.sort(comp);   
    }
    
    public void ordenar() {
        elementos.sort((Comparator<T>) Comparator.naturalOrder());
    }
    
    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(elementos);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        elementos.clear();
        try (ObjectInputStream desearializador = new ObjectInputStream(new FileInputStream(path))) {
            elementos = (List<T>) desearializador.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            for (T elem : elementos) {
                escritor.write(elem.toCSV());
                escritor.newLine(); 
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> transformacion) throws IOException {
        elementos.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                elementos.add(transformacion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
   
    // metodos para implementar Iventariable 
    
    private List<T> copiarLista(){
        return new ArrayList<>(elementos);
    }
    
    private List<T> copiarOrdenada(Comparator<? super T> comp){
        List<T> copia = copiarLista();
        copia.sort(comp);
        return copia;
    }
    
    @Override
    public Iterator<T> iterator(){
        if(!elementos.isEmpty() && elementos.get(0) instanceof Comparable){
            return iterator((Comparator<T>) Comparator.naturalOrder());
        }
        return copiarLista().iterator();
    }
    
    public Iterator<T> iterator(Comparator<? super T> comp){
        return copiarOrdenada(comp).iterator();
    }
}

            