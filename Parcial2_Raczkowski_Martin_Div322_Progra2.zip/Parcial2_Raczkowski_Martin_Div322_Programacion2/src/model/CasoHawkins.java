package model;

import persistencia.CSVSerializable;

public class CasoHawkins implements Comparable<CasoHawkins>, CSVSerializable{
    
    private static final long serialVersionUID = 1L;
    private final int id;
    private final String titulo;
    private final String investigador;
    private final ClasificacionCaso clasificacion;

    public CasoHawkins(int id, String titulo, String investigador, ClasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getInvestigador() {
        return investigador;
    }

    public ClasificacionCaso getClasificacion() {
        return clasificacion;
    }
    
    @Override
    public String toString(){
        return "CasoHawkins{" + id + "," + titulo + "," + investigador + "," + clasificacion + "}";
    }

    @Override
    public int compareTo(CasoHawkins ch) {
        return Integer.compare(id, ch.id);
    }
    
    @Override
    public String toCSV(){
        return id + "," + titulo + "," + investigador + "," + clasificacion;
    }
    
    public static CasoHawkins fromCSV(String csv){
        csv = csv.substring(0, csv.length());
        String[] datos = csv.split(",");
        return new CasoHawkins(Integer.parseInt(datos[0]), datos[1], datos[2], ClasificacionCaso.valueOf(datos[3]));
    }
    
    
    
}
