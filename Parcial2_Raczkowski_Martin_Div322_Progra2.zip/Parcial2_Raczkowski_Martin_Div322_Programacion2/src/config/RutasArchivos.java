
package config;

import java.nio.file.Path;
import java.nio.file.Paths;


public class RutasArchivos {
    
    static final String BASE = "src/data/";
    static final String FILE_CSV = "casos.csv";
    static final String FILE_DAT = "casos.dat";
    
    static Path getRutaCSV() {
        return Paths.get(BASE, FILE_CSV);
    }
    
    static Path getRutaDAT() {
        return Paths.get(BASE, FILE_DAT);
    }
    
    static String getRutaCSVString(){
        return getRutaCSV().toString();
    }
    
    static String getRutaDATString(){
        return getRutaDAT().toString();
    }
    
    
    
    
    
}
