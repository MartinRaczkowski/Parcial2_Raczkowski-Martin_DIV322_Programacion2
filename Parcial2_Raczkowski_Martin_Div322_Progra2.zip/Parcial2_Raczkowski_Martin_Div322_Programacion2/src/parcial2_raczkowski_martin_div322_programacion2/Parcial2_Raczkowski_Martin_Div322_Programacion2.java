
package parcial2_raczkowski_martin_div322_programacion2;

import java.io.IOException;
import model.CasoHawkins;
import model.ClasificacionCaso;
import model.RegistroHawkins;


public class Parcial2_Raczkowski_Martin_Div322_Programacion2 {


    public static void main(String[] args) {
        
        
        try {
            RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>();
            registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr.Brenner", ClasificacionCaso.APERTURA_DIMENSIONAL));
            registro.agregar(new CasoHawkins(2, "Actividad psíquica elevada", "Dr.Owens", ClasificacionCaso.SUJETO_PSIQUICO));
            registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "JimHopper", ClasificacionCaso.ENTIDAD_HOSTIL));
            registro.agregar(new CasoHawkins(4, "Señales electromagnéticas inusuales","Nancy Wheeler", ClasificacionCaso.FENOMENO_ELECTROMAGNETICO));
            registro.agregar(new CasoHawkins(5, "Desaparición de joven en bosque","Joyce Byers", ClasificacionCaso.DESAPARICION));
            
            System.out.println("Casos registrados:");
            registro.paraCadaElemento(e -> System.out.println(e));
             
            System.out.println("\nCasos tipo SUJETO_PSIQUICO:");
            registro.filtrar(e -> e.getClasificacion() == ClasificacionCaso.SUJETO_PSIQUICO)
                    .forEach(e -> System.out.println(e.getTitulo() + " investigado por " + e.getInvestigador()));
            
            System.out.println("\nCasos que contienen 'portal':");
            registro.filtrar(e -> e.getTitulo().contains("portal"))
                    .forEach(e -> System.out.println(e.getTitulo() + " con numero de ID " + e.getId()));
            
            System.out.println("\nCasos ordenados por ID:");
            registro.ordenar();
            registro.paraCadaElemento(e -> System.out.println("ID " + e.getId() + " es un caso de " + e.getClasificacion()));
 
            System.out.println("\nCasos ordenados por título:");
            registro.ordenar((e1, e2) -> e1.getTitulo().compareToIgnoreCase(e2.getTitulo()));
            
            registro.guardarEnArchivo("src/data/casos.dat");
            
            RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>();
            cargado.cargarDesdeArchivo("src/data/casos.dat");
            System.out.println("\nCasos cargados desde archivo binario:");
            cargado.paraCadaElemento(System.out::println);
            
            registro.guardarEnCSV("src/data/casos.csv");
            
            cargado.cargarDesdeCSV("src/data/casos.csv", lineaCSV -> CasoHawkins.fromCSV(lineaCSV));
            System.out.println("\nCasos cargados desde archivo CSV:");
            cargado.paraCadaElemento(System.out::println);
            
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
        
    }
  
}
    

