
package persistencia;

import java.io.Serializable;



public interface CSVSerializable extends Serializable {
    
    static final long serialVersionUID = 1L;
    
    String toCSV();
    
}
