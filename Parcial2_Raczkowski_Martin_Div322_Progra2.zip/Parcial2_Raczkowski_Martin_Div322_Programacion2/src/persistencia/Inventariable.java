package persistencia;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public interface Inventariable<T> extends Iterable<T>{
    
    void agregar(T item);
    
    void eliminar(int indice);
    
    T obtener(int indice);
    
    List<T> filtrar(Predicate<T> criterio);
    
    void paraCadaElemento(Consumer<T> accion);
    
}
