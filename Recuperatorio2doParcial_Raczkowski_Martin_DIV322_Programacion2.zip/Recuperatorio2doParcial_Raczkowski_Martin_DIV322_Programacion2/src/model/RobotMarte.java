
package model;


public class RobotMarte implements CSVConvertible, Comparable<RobotMarte>{
    
    private int id;
    private String nombre;
    private TipoRobot tipo;
    private int nivelBateria;
    private int anioFabricacion;
    private double kmRecorridos;

    public RobotMarte(int id, String nombre, TipoRobot tipo, int nivelBateria, int anioFabricacion, double kmRecorridos) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.nivelBateria = nivelBateria;
        this.anioFabricacion = anioFabricacion;
        this.kmRecorridos = kmRecorridos;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoRobot getTipo() {
        return tipo;
    }

    public int getNivelBateria() {
        return nivelBateria;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public double getKmRecorridos() {
        return kmRecorridos;
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + tipo + "," + nivelBateria + "," + anioFabricacion + "," + kmRecorridos;
    }

    public static String toHeaderCSV(){
        return "id,nombre,tipo,nivelBateria,anioFabricacion,kmRecorridos";
    }
            
    public static RobotMarte fromCSV(String linea){
        String[] datos = linea.split(",");
        return new RobotMarte(Integer.parseInt(datos[0]), datos[1], TipoRobot.valueOf(datos[2]), Integer.parseInt(datos[3]), Integer.parseInt(datos[4]), Double.parseDouble(datos[5]));
    }
    
    @Override
    public String toString(){
        return "RobotMarte{" + id + "," + nombre + "," + tipo + "," + nivelBateria + "," +  anioFabricacion + "," + kmRecorridos + "}";
    }
    
    @Override
    public int compareTo(RobotMarte o) {
        if(this.nivelBateria == o.nivelBateria){
            return Double.compare(kmRecorridos, o.kmRecorridos);
        }else{
            return Integer.compare(nivelBateria, o.nivelBateria);
        }
    }
    
    
}
