
package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import model.RobotMarte;


public class Inventario<T extends CSVConvertible> implements Almacenable<T>{

    private List<T> elementos = new ArrayList<>() {};
    
    @Override
    public void agregar(T elemento) {
        Objects.requireNonNull(elemento, "Elemento nulo");
        elementos.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        Iterator<T> iterador = iterator();
        while(iterador.hasNext()){
            if(criterio.test(iterador.next())){
                iterador.remove();
            }
        }
        elementos = List.copyOf((Collection<? extends T>) iterador);
    }

    @Override
    public List<T> obtenerTodos() {
        return new ArrayList<>(elementos);
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        for (T elem : elementos) {
            if (criterio.test(elem)) {
                return elem;
            }
        }
        return null;
    }

    @Override
    public void ordenar() {
        elementos.sort((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        elementos.sort(comparator);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrada = new ArrayList<>();
        for (T elem : elementos) {
            if (criterio.test(elem)) {
                filtrada.add(elem);
            }
        }
        return filtrada;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> resultado = new ArrayList<>();
        
        for (T elemento : elementos) {
            T elementoTransformado = operador.apply(elemento);
            resultado.add(elementoTransformado);
        }
        
        return resultado;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int cuenta = 0;
        for (T elem : elementos) {
            if (criterio.test(elem)) {
                cuenta++;
            }
        }
        return cuenta;
    }

    @Override
    public Iterator<T> iterator() {
        return obtenerTodos().iterator();
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            serializador.writeObject(elementos);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        elementos.clear();
        try (ObjectInputStream desearializador = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) desearializador.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            escritor.write(RobotMarte.toHeaderCSV());
            escritor.newLine();
            for (T elem : elementos) {
                escritor.write(elem.toCSV());
                escritor.newLine(); 
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        elementos.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            lector.readLine();
            String linea;
            while ((linea = lector.readLine()) != null) {
                elementos.add(fromCSV.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    
    
}
