
package model;

import java.io.Serializable;


public interface CSVConvertible extends Serializable{
    
    static final long serialVersionUID = 1L;
    
    String toCSV();
    
}
